package com.gabriel1803.demojpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemojpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
