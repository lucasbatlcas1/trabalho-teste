package com.alessiojr.demojpa.domain;

import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import javax.persistence.*;
import java.time.Instant;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity(name = "table_avaliacaooo")
public class Avaliacao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "nome", length = 64)
    private String nome;
    @Column(name = "nomeProfessor", length = 64)
    private String nomeP;
    private String instrucoes;  
    
    private Boolean isActive;
    private int questoes;
    private float valor;
    private int n_tentativas;
    private float tempodeduracao;

    public static Avaliacao parseNote(String line) {
        String[] text = line.split(",");
        Avaliacao note = new Avaliacao();
        note.setId(Long.parseLong(text[0]));
        note.setNome(text[1]);
        return note;
    }
}
